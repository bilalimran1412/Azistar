import React from 'react';
import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { GoogleOAuthProvider, GoogleLogin } from '@react-oauth/google';
import { jwtDecode } from 'jwt-decode';
import { Modal, ModalOverlay, ModalContent, ModalHeader, ModalCloseButton, ModalBody, ModalFooter } from '@chakra-ui/react';
import { FiFile, FiSearch } from 'react-icons/fi'; 
import {
  Button,
  Icon,
  Text,
  Accordion,
  AccordionItem,
  AccordionButton,
  AccordionPanel,
  AccordionIcon,
  Grid,
  GridItem,
  Input,
  InputGroup,
  InputLeftElement,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Image,
  Box,
  Flex,
} from '@chakra-ui/react';
import { SidebarFormCard, SidebarFormContainer } from '../Shared/SidebarUi';
import { useNodeContext } from '../../views/canvas/NodeContext';
import { nodeConfigurationBlockIdMap } from '../../config/nodeConfigurations';
import { yup } from '../../utils/yup';
import { FaGoogle } from 'react-icons/fa';

import {
  FormDropdown,
  FormVariableSelectorDropdown,
  RowFieldArray,
} from '../Shared/FormUi';

import { useFormikContext } from 'formik';
import { MdClose } from 'react-icons/md';

const options = [
  { label: 'gmailuser@gmail.com', value: '23' },
  { label: 'User1@gmail.com', value: '32' },
];


function GoogleSheetsNodeContent({ id }) {
  const { getNodeById, setSideView, updateNodeById } = useNodeContext();
  const currentNode = getNodeById(id);
  const config = options;
  const handleClose = () => {
    setSideView(false);
  };
  if (!config) return <></>;
  // console.log('creating sidebar for block', config);

  const initialValues = {
    account: currentNode?.data?.params?.account || '',
    spreadSheet: currentNode?.data?.params?.spreadSheet || '',
    sheet: currentNode?.data?.params?.sheet || '',
  };
  const validationSchema = yup.object({});

  const onSave = (formValues) => {
    console.log('Form values=>>>', formValues);
    updateNodeById(id, { params: { ...formValues } });
    handleClose();
  };


  return (
    <SidebarFormContainer
      block={config}
      onClose={handleClose}
      onFormSave={onSave}
      initialValues={initialValues}
      validationSchema={validationSchema}
      onReset={handleClose}
    >
      <AccordionContent />
      <ActionFormFields />

    </SidebarFormContainer>
  );
}

export default GoogleSheetsNodeContent;


function AccordionContent() {
  const [accessToken, setAccessToken] = useState(null);
  const [email, setEmail] = useState('');  // State to store the user's email
  const [spreadSheets, setSpreadSheets] = useState([]);
  const [options, setOptions] = useState([]);
  const [isFetching, setIsFetching] = useState(false);
  const [values, setValues] = useState({
    spreadSheet: '',
    sheet: '',
  });
  const baseURL = process.env.REACT_APP_API_BASE_URL;
  const { id } = useParams();
  console.log('oh ai h', id)
  // Handle Google login redirect
  const handleGoogleLogin = () => {
    // const authUrl = `https://accounts.google.com/signin/oauth/error/v2?authError=ChVyZWRpcmVjdF91cmlfbWlzbWF0Y2gSsAEKWW91IGNhbid0IHNpZ24gaW4gdG8gdGhpcyBhcHAgYmVjYXVzZSBpdCBkb2Vzbid0IGNvbXBseSB3aXRoIEdvb2dsZSdzIE9BdXRoIDIuMCBwb2xpY3kuCgpJZiB5b3UncmUgdGhlIGFwcCBkZXZlbG9wZXIsIHJlZ2lzdGVyIHRoZSByZWRpcmVjdCBVUkkgaW4gdGhlIEdvb2dsZSBDbG91ZCBDb25zb2xlLgogIBptaHR0cHM6Ly9kZXZlbG9wZXJzLmdvb2dsZS5jb20vaWRlbnRpdHkvcHJvdG9jb2xzL29hdXRoMi93ZWItc2VydmVyI2F1dGhvcml6YXRpb24tZXJyb3JzLXJlZGlyZWN0LXVyaS1taXNtYXRjaCCQAypLCgxyZWRpcmVjdF91cmkSO2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9ib3QvYnVpbGRlci82NzM0NzdjYzA3Mjk0MTJlZTQ1YjI5MjEvMqQCCAESsAEKWW91IGNhbid0IHNpZ24gaW4gdG8gdGhpcyBhcHAgYmVjYXVzZSBpdCBkb2Vzbid0IGNvbXBseSB3aXRoIEdvb2dsZSdzIE9BdXRoIDIuMCBwb2xpY3kuCgpJZiB5b3UncmUgdGhlIGFwcCBkZXZlbG9wZXIsIHJlZ2lzdGVyIHRoZSByZWRpcmVjdCBVUkkgaW4gdGhlIEdvb2dsZSBDbG91ZCBDb25zb2xlLgogIBptaHR0cHM6Ly9kZXZlbG9wZXJzLmdvb2dsZS5jb20vaWRlbnRpdHkvcHJvdG9jb2xzL29hdXRoMi93ZWItc2VydmVyI2F1dGhvcml6YXRpb24tZXJyb3JzLXJlZGlyZWN0LXVyaS1taXNtYXRjaA%3D%3D&client_id=1025865763011-693q79e02tqb87hdaa1qr7d9pgkqnh6o.apps.googleusercontent.com&flowName=GeneralOAuthFlow`
    // const authUrl = `https://accounts.google.com/o/oauth2/auth?client_id=1025865763011-693q79e02tqb87hdaa1qr7d9pgkqnh6o.apps.googleusercontent.com&redirect_uri=http://localhost:3000/bot/builder/${id}/&response_type=code&scope=https://www.googleapis.com/auth/drive.readonly https://www.googleapis.com/auth/spreadsheets.readonly&access_type=offline`;
    const authUrl = `https://accounts.google.com/o/oauth2/auth?client_id=1025865763011-693q79e02tqb87hdaa1qr7d9pgkqnh6o.apps.googleusercontent.com&redirect_uri=http://localhost:3000/bot/&response_type=code&scope=https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/drive.readonly https://www.googleapis.com/auth/spreadsheets.readonly&access_type=offline`;
    const width = 800;
    console.log(authUrl)
    const height = 600;
    const left = (window.innerWidth - width) / 2;
    const top = (window.innerHeight - height) / 2;

    // Open the Google OAuth login popup
    const popupWindow = window.open(
      authUrl,
      'Google Login',
      `width=${width},height=${height},top=${top},left=${left}`
    );

    // Listen for the message from the popup window containing the authorization code
    const messageListener = (event) => {
      // Only accept messages from the popup window origin
      if (event.origin !== 'http://localhost:3000') return;

      const { code } = event.data;
      console.log(code)
      if (code) {
        handleLoginCode(code);
      }
    };

    // Add event listener for postMessage
    window.addEventListener('message', messageListener);

    // Clean up the event listener once the popup is closed
    popupWindow.onbeforeunload = () => {
      window.removeEventListener('message', messageListener);
    };
  };

  useEffect(() => {
    const queryParams = new URLSearchParams(window.location.search);
    const code = queryParams.get('code');

    if (code) {
      handleLoginCode(code);
    }
  }, []);

  const handleLoginCode = async (code) => {
    setIsFetching(true);
    try {
      const response = await fetch(`${baseURL}/integrate/google/auth`, {
        method: 'POST',
        body: JSON.stringify({ code }),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      setIsFetching(false);

      // Check if email and sheets are available
      if (data.email && data.sheets) {
        setEmail(data.email); // Set email from backend response
        setSpreadSheets(data.sheets); // Set sheets from backend response
      } else {
        console.error('Error: Email or Sheets data not available.');
      }
      console.log(data)
    } catch (error) {
      setIsFetching(false);
      console.error('Error during login:', error);
    }
  }


  const clearValue = () => {
    setValues(prev => ({
      ...prev,
      spreadSheet: '',
      sheet: '',
    }));
  };

  return (
    <Accordion allowToggle defaultIndex={0} style={{ marginTop: '-10px' }} marginX='-19px'>
      <AccordionItem border='none'>
        <h2>
          <AccordionButton backgroundColor='rgba(0, 0, 0, 0.04)'>
            <Box flex='1' textAlign='left'>
              <Text>Create Account or File</Text>
            </Box>
            <AccordionIcon />
          </AccordionButton>
        </h2>

        <AccordionPanel pb={4}>
          <Flex direction='column' gap={8}>
            <SidebarFormCard title='Log into your account' containerProps={{ padding: 4 }} contentContainerProps={{ marginTop: 1 }}>
              <Box display='flex' flexDirection='column' gap={2}>
                <Text>Login with google to access your files.</Text>
                <Button
                  variant='outline'
                  width='full'
                  maxW='md'
                  borderColor='gray.300'
                  _hover={{ bg: 'gray.100', boxShadow: 'md' }}
                  _active={{ bg: 'gray.200' }}
                  backgroundColor={'#fff'}
                  size='lg'
                  height='40px'
                  justifyContent='flex-start'
                  onClick={handleGoogleLogin}
                >
                  <Text fontSize='14px' fontFamily='Roboto, arial, sans-serif' flex={1}>
                    Login with Google
                  </Text>
                </Button>
                <>
                  <Text>Welcome, {email}</Text>
                  <FormDropdown
                    name='account'
                    options={[{ label: email, value: email }, ...options]} label=''
                    labelVariant='h3'
                    variant='custom'
                  />
                </>
              </Box>
            </SidebarFormCard>
            <SidebarFormCard title='Select Spreadsheet' containerProps={{ padding: 4 }} contentContainerProps={{ marginTop: 1 }}>
              <SelectFileContent
                accessToken={accessToken}
                setSpreadSheets={setSpreadSheets}
                spreadSheets={spreadSheets}
                values={values}
                setFieldValue={(name, value) => setValues(prev => ({ ...prev, [name]: value }))}
                isFetching={isFetching}
              />
            </SidebarFormCard>
          </Flex>
        </AccordionPanel>
      </AccordionItem>
    </Accordion>
  );
}


function SelectFileContent({ accessToken, setSpreadSheets, spreadSheets, values, setFieldValue, isFetching }) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSheet, setSelectedSheet] = useState(null);

  // Filter spreadsheets based on search query
  const filteredSheets = spreadSheets.filter((sheet) =>
    sheet.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const clearValue = () => {
    setFieldValue('spreadSheet', '');
    setFieldValue('sheet', '');
  };

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedSheet(null); // Clear selection when closing modal
  };

  const confirmSelection = () => {
    if (selectedSheet) {
      setFieldValue('spreadSheet', selectedSheet.id); // Set the selected sheet's ID
      closeModal(); // Close modal
    }
  };

  return (
    <Box display="flex" flexDirection="column" gap={2}>
      <Text>Select a file to save or obtain data.</Text>
      <Flex gap={2} width="100%" flexDirection="column" alignItems="">
        <Button
          variant="outline"
          width="full"
          maxW="full"
          borderColor="gray.300"
          _hover={{ bg: 'gray.100', boxShadow: 'md' }}
          _active={{ bg: 'gray.200' }}
          backgroundColor="#fff"
          size="lg"
          height="40px"
          isLoading={isFetching}
          onClick={openModal}
        >
          <Text fontSize="14px" fontFamily="Roboto, arial, sans-serif" flex={1}>
            {values?.spreadSheet ? 'File Selected' : 'Select file'}
          </Text>
        </Button>
        {values?.spreadSheet && (
          <Input
            type="text"
            readOnly
            ml={2}
            fontSize="sm"
            color="gray.500"
            value={spreadSheets.find((sheet) => sheet.id === values.spreadSheet)?.name}
            width="full"
            maxW="full"
            m="0"
          />
        )}
      </Flex>

      {/* Modal */}
      <Modal isOpen={isModalOpen} onClose={closeModal}>
        <ModalOverlay />
        <ModalContent maxWidth="90%" width="90%">
          <ModalHeader>Select a Spreadsheet</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Tabs variant="enclosed">
              <TabList>
                <Tab>Spreadsheets</Tab>
              </TabList>
              <TabPanels>
                <TabPanel>
                  {/* Search Bar */}
                  <Flex mb={4}>
                    <InputGroup>
                      <InputLeftElement pointerEvents="none">
                        <FiSearch color="gray.500" />
                      </InputLeftElement>
                      <Input
                        placeholder="Search spreadsheets"
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </InputGroup>
                  </Flex>

                  {/* Grid Display */}
                  {filteredSheets.length > 0 ? (
                    <Grid templateColumns="repeat(4, 1fr)" gap={4}>
                      {filteredSheets.map((sheet) => (
                        <GridItem
                          key={sheet.id}
                          cursor="pointer"
                          _hover={{ bg: 'gray.100', boxShadow: 'md' }}
                          onClick={() => setSelectedSheet(sheet)}
                          p={4}
                          border="2px solid"
                          borderColor={selectedSheet?.id === sheet.id ? 'blue.500' : 'gray.300'}
                          borderRadius="8px"
                          textAlign="center"
                          bg={selectedSheet?.id === sheet.id ? 'blue.50' : 'white'}
                        >
                          {/* Display Sheet Preview or Placeholder */}
                          {sheet.imageUrl ? (
                            <Image src={sheet.imageUrl} alt={sheet.name} boxSize="100px" mx="auto" />
                          ) : (
                            <Icon as={FiFile} boxSize={12} color="gray.500" />
                          )}
                          <Text fontSize="14px" mt={2} isTruncated>
                            {sheet.name}
                          </Text>
                        </GridItem>
                      ))}
                    </Grid>
                  ) : (
                    <Text>No spreadsheets available.</Text>
                  )}
                </TabPanel>
              </TabPanels>
            </Tabs>
          </ModalBody>
          <ModalFooter>
            <Flex width="100%" justifyContent="space-between">
              <Button variant="outline" onClick={clearValue}>
                Clear Selection
              </Button>
              <Flex gap={2}>
                <Button variant="outline" onClick={closeModal}>
                  Close
                </Button>
                <Button
                  colorScheme="blue"
                  onClick={confirmSelection}
                  isDisabled={!selectedSheet} // Disable if no sheet is selected
                >
                  Select
                </Button>
              </Flex>
            </Flex>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>
  );  
}






function ActionFormFields() {
  const { values } = useFormikContext();
  if (!values.sheet) {
    return <></>;
  }
  return (
    <>
      <SidebarFormCard
        title='Action to perform'
        containerProps={{ padding: 4 }}
        contentContainerProps={{ marginTop: 1 }}
      >
        <FormDropdown
          name='action'
          options={options}
          label=''
          labelVariant='h3'
          variant='custom'
        />
      </SidebarFormCard>

      <SidebarFormCard
        title='Set a reference column'
        containerProps={{ padding: 4 }}
        contentContainerProps={{ marginTop: 1 }}
      >
        <Text mb={2}>
          Select a reference column and its related field to identify which row
          to update.
        </Text>
        <Box bg='#8a9ba826' borderRadius='3px' p='10px 12px 9px'>
          <Flex direction='column' width='100%' alignItems='flex-end'>
            <Box width='100%'>
              <FormDropdown
                label=''
                placeholder='Select the field'
                name={`field`}
                options={[]}
                variant='custom'
              />
              <FormVariableSelectorDropdown
                name={`variable`}
                placeholder='Select a variable'
                label=''
              />
            </Box>
          </Flex>
        </Box>
      </SidebarFormCard>

      <SidebarFormCard
        title='New row'
        containerProps={{ padding: 4 }}
        contentContainerProps={{ marginTop: 1 }}
      >
        <Text mb={2}>
          Specify which fields should be sent to the file and assign them to
          specific columns.
        </Text>
        <RowFieldArray />
      </SidebarFormCard>
    </>
  );
}
