import React from 'react';
import BaseNode from './BaseNode';

export const CustomNode = (props) => {
  return <BaseNode {...props} />;
};
