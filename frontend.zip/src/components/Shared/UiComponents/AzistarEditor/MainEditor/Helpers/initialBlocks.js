export const initialBlocks = {
  blocks: [
    {
      key: '3eesq',
      text: 'Draft.js. Editor Click to edit. :)',
      type: 'unstyled',
      depth: 0,
      inlineStyleRanges: [
        {
          offset: 19,
          length: 6,
          style: 'BOLD',
        },
        {
          offset: 25,
          length: 5,
          style: 'ITALIC',
        },
        {
          offset: 30,
          length: 8,
          style: 'UNDERLINE',
        },
      ],
      entityRanges: [],
      data: {},
    },
  ],
  entityMap: {},
};
