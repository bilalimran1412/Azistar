import React from 'react';

function VariablesPopup() {
  return <button type='button'>Variables</button>;
}

export default VariablesPopup;
