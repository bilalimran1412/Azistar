export const weekdays = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
];

export const radioOptions = [
  { label: 'Single day', value: 'day' },
  { label: 'Date range', value: 'range' },
];
