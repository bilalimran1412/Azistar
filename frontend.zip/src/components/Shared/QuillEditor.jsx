// import React from 'react';
// import { FormControl, FormLabel } from '@chakra-ui/react';
// import ReactQuill from 'react-quill';

// const modules = {
//   toolbar: [
//     ['bold', 'italic', 'underline'],
//     [{ header: '1' }],
//     [{ list: 'ordered' }, { list: 'bullet' }],
//     ['link'],
//     ['blockquote', 'code-block'],
//   ],
// };
// function QuillEditor() {
//   return (
//     <FormControl mt={4}>
//       <FormLabel>Question Here</FormLabel>
//       <ReactQuill
//         theme='snow'
//         value={''}
//         placeholder={'PlaceHolder'}
//         modules={modules}
//       />
//     </FormControl>
//   );
// }

// export default QuillEditor;
import React from 'react';

function QuillEditor() {
  return <div>QuillEditor</div>;
}

export default QuillEditor;
