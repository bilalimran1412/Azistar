import React from 'react'
import GetDetails from '../views/LiveChat/DataSource/GetDetails'
import Layout from '../components/Layout/Layout'

function getdatasource() {
  return (
    <Layout>
        <GetDetails/>
    </Layout>
  )
}

export default getdatasource