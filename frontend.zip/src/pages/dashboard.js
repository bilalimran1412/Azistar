import React from 'react'
import Layout from '../components/Layout/Layout'

function dashboard() {
  return (
    <Layout>
      <div>
        <h1>dashboard</h1>
      </div>
    </Layout>
  )
}

export default dashboard