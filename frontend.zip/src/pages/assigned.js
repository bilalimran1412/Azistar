import React from 'react'
import Layout from '../components/Layout/Layout'
import Assigned from '../views/Assigned'

function assigned() {
  return (
    <Layout>
        <Assigned/>
    </Layout>
  )
}

export default assigned