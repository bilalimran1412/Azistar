import React from 'react'
import Usermessage from '../views/LiveChat/userMessage/userMessage'
import Layout from '../components/Layout/Layout'

function usermessage() {
  return (
    <Layout>
        <Usermessage/>
    </Layout>
  )
}

export default usermessage