import React from 'react'
import Layout from '../components/Layout/Layout'
import Unassigned from '../views/Unassigned'

function unassigned() {
  return (
    <Layout>
        <Unassigned/>
    </Layout>
  )
}

export default unassigned