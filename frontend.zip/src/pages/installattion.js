import React from 'react'
import Layout from '../components/Layout/Layout'
import Installattion from '../views/Settings/Installattion'

function installattion() {
  return (
    <Layout>
        <Installattion/>
    </Layout>
  )
}

export default installattion