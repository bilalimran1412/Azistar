import GoogleSheetsNodeContent from 'components/BlockSideViewContent/GoogleSheetsNodeContent'
import React from 'react'

function bot() {
  return (
    <GoogleSheetsNodeContent/>
  )
}

export default bot