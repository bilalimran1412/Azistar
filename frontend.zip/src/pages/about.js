import React from 'react'
import Layout from '../components/Layout/Layout'

function about() {
  return (
    <Layout>
      <div>about</div>
    </Layout>
  )
}

export default about