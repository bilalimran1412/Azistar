import React from 'react'
import Chatbot from '../views/chatbot/Chatbot'


function livebot() {
  return (
    <div>
      <Chatbot/>
    </div>
  )
}

export default livebot
