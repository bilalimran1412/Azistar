import React from 'react'
import Layout from '../components/Layout/Layout'
import Solved from '../views/Solved'

function solved() {
  return (
    <Layout>
        <Solved/>
    </Layout>
  )
}

export default solved