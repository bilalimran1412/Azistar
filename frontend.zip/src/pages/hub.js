import React from 'react'
import Layout from '../components/Layout/Layout'
import Hub from '../views/Hub'

function hub() {
  return (
    <Layout>
        <Hub/>
    </Layout>
  )
}

export default hub