import React from 'react'
import DataSource from '../views/LiveChat/DataSource/datasource'
import Layout from '../components/Layout/Layout'

function datasource() {
  return (
    <Layout>
        <DataSource />
    </Layout>
  )
}

export default datasource