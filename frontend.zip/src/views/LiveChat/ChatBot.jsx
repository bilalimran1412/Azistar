import React, { useState, useEffect, useImperativeHandle, forwardRef, useRef } from 'react';
import axios from 'axios';
import '../Styles/chatbot.css';
import Sentiment from 'sentiment';
import { NotifiyIcon } from 'views/Unassigned/icons';
import { MdRateReview } from 'react-icons/md';

const Chatbot = forwardRef((props, ref) => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [initiateLiveChat, setInitiateLiveChat] = useState(false);
  const [whatsAppUrl, setWhatsAppUrl] = useState('');
  const audioRef = React.useRef(null);
  const [nodes, setNodes] = useState([]);
  const [error, setError] = useState(null);
  const [currentNodeIndex, setCurrentNodeIndex] = useState(0); // Track which node is displayed
  const [showForm, setShowForm] = useState(false);
  const baseURL = process.env.REACT_APP_API_BASE_URL;
  const sentimentAnalyzer = new Sentiment();
  const menuRef = useRef(null);
  // useEffect(() => {
  //   const getData = async () => {
  //     try {
  //       const userId = localStorage.getItem('userId');
  //       const token = localStorage.getItem('token');

  //       const res = await fetch(`${baseURL}/bot/listbots/${userId}`, {
  //         method: 'GET',
  //         headers: {
  //           'Authorization': `Bearer ${token}`,
  //           'Content-Type': 'application/json',
  //         },
  //       });

  //       if (!res.ok) {
  //         throw new Error(`Failed to fetch data: ${res.statusText}`);
  //       }

  //       const responseData = await res.json();
  //       if (responseData.data && Array.isArray(responseData.data) && responseData.data.length > 0) {
  //         setNodes(responseData.data);
  //         console.log('nodes data', responseData.data)
  //         // Call displayNode after a short delay to ensure nodes are set
  //         // setTimeout(() => displayNode(0), 100);
  //       } else {
  //         throw new Error('No diagram data available or invalid structure');
  //       }
  //     } catch (err) {
  //       console.error(err);
  //       setError(err.message);
  //     } finally {
  //       setLoading(false);
  //     }
  //   };

  //   getData();
  // }, []);

  // useEffect(() => {
  //   setTimeout(() => {
  //     if (nodes.length > 0) {
  //       console.log('Nodes are loaded, calling displayNode');
  //       displayNode(0);
  //     }
  //   }, 2500);
  // }, [nodes]);

  // // Function to display a specific node and show the form
  // const displayNode = (index) => {
  //   if (index < nodes.length) {
  //     setShowForm(true);
  //   } else {
  //     setShowForm(false);
  //   }
  // };


  // const handleFormSubmit = (event, index) => {
  //   event.preventDefault();

  //   console.log('Handling submit for node index:', currentNodeIndex);

  // // Ensure index is within bounds and node exists
  // if (currentNodeIndex < 0 || currentNodeIndex >= nodes.length || !nodes[currentNodeIndex]) {
  //   console.error('Invalid index or node not available');
  //   return; // Stop further execution if invalid
  // }

  // // Proceed with the form submission logic
  // setMessages(prevMessages => [
  //   ...prevMessages,
  //   { text: `Content Type: ${nodes[currentNodeIndex].contentType || 'No content type'}`, sender: 'bot' },
  // ]);

  //   // Add the user's message
  //   setMessages(prevMessages => [
  //     ...prevMessages,
  //     { text: input, sender: 'user' }
  //   ]);

  //   setInput('');
  //   setShowForm(false);

  //   setCurrentNodeIndex((prevIndex) => {
  //     const newIndex = prevIndex + 1;
  //     if (newIndex < nodes.length) {
  //       setTimeout(() => displayNode(newIndex), 1000);
  //     }
  //     return newIndex;
  //   });
  // };


  useEffect(() => {
    if (initiateLiveChat) {
      window.open(whatsAppUrl, '_blank');
    }
  }, [initiateLiveChat]);

  const emojiMapping = {
    positive: '😊',
    negative: '😞',
    neutral: '😐',
  };

  const getToneEmoji = (tone) => {
    switch (tone) {
      case 'positive':
        return emojiMapping.positive;
      case 'negative':
        return emojiMapping.negative;
      case 'neutral':
      default:
        return emojiMapping.neutral;
    }
  };

  const analyzeTone = (message) => {
    const result = sentimentAnalyzer.analyze(message);
    const score = result.score;
    if (score > 0) return 'positive';
    if (score < 0) return 'negative';
    return 'neutral';
  };


  // Send Input message
  useImperativeHandle(ref, () => ({
    sendMessage: async (message) => {
      if (!message.trim()) return;

      const userId = localStorage.getItem('userId');

      try {
        setLoading(true);
        const response = await axios.post(`${baseURL}/chat/live`, { message, userId });
        const { response: chatbotResponse, initiateLiveChat, whatsappUrl } = response.data;

        if (initiateLiveChat) {
          setInitiateLiveChat(true);
          setWhatsAppUrl(whatsappUrl);
        } else {
          setMessages(prevMessages => [...prevMessages, { text: message, sender: 'user' }]);
          setTimeout(() => {
            setLoading(false);
            setMessages(prevMessages => [...prevMessages, { text: chatbotResponse, sender: 'bot' }]);
            audioRef.current.play();
          }, 1000);
        }
      } catch (error) {
        setLoading(false);
        console.error('Error sending message:', error);
      }
    },
  }));


  // Send Message
  const sendMessage = async (event) => {
    event.preventDefault();
    if (!input.trim()) return;
    const userId = localStorage.getItem('userId');

    const tone = analyzeTone(input);
    const toneEmoji = getToneEmoji(tone);

    try {
      setLoading(true);
      const response = await axios.post(`${baseURL}/chat/live`, { message: input, userId });
      const { response: chatbotResponse, initiateLiveChat, whatsappUrl } = response.data;

      if (initiateLiveChat) {
        // Hide the chatbot input and messages container
        setInitiateLiveChat(true);
        setWhatsAppUrl(whatsappUrl)

      } else {
        // Show chatbot response
        setMessages(prevMessages => [...prevMessages, { text: `${toneEmoji} ${input}`, sender: 'user' }]);
        setTimeout(() => {
          setLoading(false);
          const botTone = analyzeTone(chatbotResponse);
          const botToneEmoji = getToneEmoji(botTone);

          setMessages(prevMessages => [...prevMessages, { text: `${botToneEmoji} ${chatbotResponse}`, sender: 'bot' }]);
          audioRef.current.play();
          console.log('bottone', botToneEmoji)
        }, 1000);
      }
    } catch (error) {
      setLoading(false);
      console.error('Error sending message:', error);
    }

    setInput('');
  };



  const buttonStyle = {
    background: 'linear-gradient(135deg, rgb(42, 39, 218), rgb(0, 204, 255))',
    boxShadow: 'rgba(0, 77, 255, 0.5) 0px 2px 16px',
  };

  const materialIconStyle = {
    color: 'rgb(255, 255, 255)',
  };

  useEffect(() => {
    const initialMessage = { text: "Hi!", sender: 'user' };
    setMessages([initialMessage]);
    const timer = setTimeout(() => {
      const botResponse = { text: "Hi there! 😊 How can I help you today?", sender: 'bot' };
      setMessages(prevMessages => [...prevMessages, botResponse]);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const [displayChat, SetDisplayChat] = useState('');
  const [displayOptions, setDisplayOptions] = useState(false);
  const [displayOptionsClass, setDisplayOptionsClass] = useState('close_options');

  const hideChat = () => {
    SetDisplayChat('hide_chat');
  }
  const display_Chat = () => {
    SetDisplayChat('display_active_chat');
  }

  const toggleDisplayOptions = () => {
    setDisplayOptions((prev) => !prev); 
    setDisplayOptionsClass((prev) => (prev === 'close_options' ? 'open_options' : 'close_options')); // Toggle the class
  };

  const handleClickOutside = (event) => {
    if (menuRef.current && !menuRef.current.contains(event.target)) {
      setDisplayOptions(false);
      setDisplayOptionsClass('close_options');
    }
  };

  useEffect(() => {
    window.onclick = handleClickOutside;
    return () => {
      window.onclick = null;
    };
  }, []);

  return (
    <div className={`main_bot_ground ${displayChat}`}>
      <div className={`chatbot-container chat`}>
        <div className={` chatbot_conteainer`}>
          <audio ref={audioRef} src="https://widget-v4.tidiochat.com/tururu.mp3" preload="auto" />
          <div className="chat-header project-online" style={{ color: 'rgb(255, 255, 255)', background: 'linear-gradient(135deg, rgb(42, 39, 218) 0%, rgb(0, 204, 255) 100%)' }}>
            <div className="avatars-wrapper operators-avatar-1">
              <div className="header-ava"></div>
            </div>
            <h2 className="oneline">
              <span>Hi there <img src="https://cdnjs.cloudflare.com/ajax/libs/twemoji/12.1.1/72x72/1f44b.png" alt="👋" className="emoji" /></span>
            </h2>
            <button onClick={hideChat} className="material-icons exit-chat ripple tidio-1s5t5ku" type="button" aria-label="Minimize" style={{ color: 'rgb(255, 255, 255)' }}>
              <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" id="ic-minimize">
                <path d="M0 0h24v24H0z" fill="none"></path>
                <path d="M11.67 3.87L9.9 2.1 0 12l9.9 9.9 1.77-1.77L3.54 12z"></path>
              </svg>
              <span>Minimize</span>
            </button>
            <button onClick={toggleDisplayOptions} className="material-icons options ripple tidio-1s5t5ku" type="button" aria-label="Open options" style={{ color: 'rgb(255, 255, 255)' }}>
              <svg id="ic_options" className="options-icon" fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <path d="M0 0h24v24H0z" fill="none"></path>
                <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"></path>
              </svg>
              <span>Open options</span>
            </button>
            {displayOptions ? (
              <div className={`${displayOptionsClass} notifications_display`}>
                <button className='notification_option'>
                  <NotifiyIcon/>
                  Turn off Notifications</button>
                <button className='notification_option'>
                  <MdRateReview/> Rate this conversation</button>
              </div>
            ) : null}

            <div className="offline-message" style={{ backgroundImage: 'linear-gradient(135deg, rgba(42, 39, 218, 0.72) 0%, rgba(0, 204, 255, 0.72) 100%)' }}>
              <span className="online"><span>We reply immediately</span></span>
            </div>
          </div>
          <div className="chatbot-header"> </div>
          <div className="chatbot-wrapper">
            <div className={`chatbot-messages ${showForm ? 'show-form-active' : ''}`}>
              {messages.map((msg, index) => (
                <div key={index} className={`message ${msg.sender} p-2 rounded-lg mb-2 ${msg.sender === 'bot' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-800'}`}>
                  {msg.text}
                </div>
              ))
              }


              {loading && (
                <div className="message bot p-2 rounded-lg mb-2 bg-gray-200 text-gray-800">
                  <span>{initiateLiveChat ? 'Initiated WhatsApp Live chat.' : 'Loading...'}</span>
                  <span className="dot1">.</span>
                  <span className="dot2">.</span>
                  <span className="dot3">.</span>
                </div>
              )}
            </div>

            <form onSubmit={sendMessage}>
              <div className="chatbot-input mt-4">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Type your message..."
                  className="mb-4 w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none"
                />
                {/* <button onClick={sendMessage} className="bg-blue-500 text-white rounded-lg px-4 py-2 ml-2 focus:outline-none">Send</button> */}
                <div id="button" data-testid="widgetButton" className="chat-open mobile-size__large bubbleAnimation-appear-done bubbleAnimation-enter-done">
                  <div className="buttonWave"></div>
                  <button type="submit" id="button-body" data-testid="widgetButtonBody" className="chrome" tabIndex="0" aria-label="Close chat widget" style={buttonStyle}>
                    <i className="material-icons type1 for-closed" style={materialIconStyle}>
                      <svg id="ic_bubble" fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"></path>
                        <path d="M0 0h24v24H0z" fill="none"></path>
                      </svg>
                    </i>
                    <i className="material-icons type2 for-closed">
                      <svg id="ic_create" fill="blue" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"></path>
                        <path d="M0 0h24v24H0z" fill="none"></path>
                      </svg>
                    </i>
                    <i className="material-icons type1 for-opened active" style={materialIconStyle}>
                      <svg id="ic_send" fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path>
                        <path d="M0 0h24v24H0z" fill="none"></path>
                      </svg>
                    </i>
                    <i className="material-icons type2 for-opened active">
                      <svg id="ic_send" fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                        <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path>
                        <path d="M0 0h24v24H0z" fill="none"></path>
                      </svg>
                    </i>
                  </button>
                </div>
              </div>
            </form>



          </div>
        </div>
        
      </div >
      <div id="button" data-testid="widgetButton" className="open_chatbutton toggle_chat_btn chat-open mobile-size__large bubbleAnimation-appear-done bubbleAnimation-enter-done">
          <div className="buttonWave"></div>
          <button onClick={display_Chat} id="button-body" data-testid="widgetButtonBody" className="chrome" tabIndex="0" aria-label="Close chat widget" style={buttonStyle}>
          <i className="material-icons type1 for-closed active" style={{ color: 'rgb(255, 255, 255)' }}><svg id="ic_bubble" fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"></path><path d="M0 0h24v24H0z" fill="none"></path></svg></i>
          <i className="material-icons type2 for-closed" id='hover_icons'><svg id="ic_create" fill="blue" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"></path><path d="M0 0h24v24H0z" fill="none"></path></svg></i>
          {/* <i className="material-icons type1 for-opened " style={{color: 'rgb(255, 255, 255)'}}><svg id="ic_send" fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path><path d="M0 0h24v24H0z" fill="none"></path></svg></i> */}
          {/* <i className="material-icons type2 for-opened "><svg id="ic_send" fill="#FFFFFF" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path><path d="M0 0h24v24H0z" fill="none"></path></svg></i> */}
          </button>
        </div>
    </div>
  );
})

export default Chatbot;
