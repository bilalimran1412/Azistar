import React, { useState, useEffect, useRef } from 'react';
import PopUp from 'components/PopUp/PopUp';
import Loader from '../Loader/Loader';
import { BsTrash } from 'react-icons/bs';
import { MdAdd, MdVideoLabel } from 'react-icons/md';
import '../live-chat.css';
import { Link } from '@chakra-ui/react';
import '../../Styles/playground_ai.css';

function extractWebsiteName(url) {
  try {
    if (!/^https?:\/\//i.test(url)) {
      url = 'http://' + url;
    }
    const { hostname } = new URL(url);
    return hostname;
  } catch (error) {
    console.error('Invalid URL:', url);
    return 'Unknown';
  }
}

function GetDetails() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedWebsiteData, setSelectedWebsiteData] = useState(null);
  const [selectedWebsite, setSelectedWebsite] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    tag: '',
    pattern: '',
    response: '',
    id: '',
  });
  const baseURL = process.env.REACT_APP_API_BASE_URL;
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredData, setFilteredData] = useState(data);
  const [message, setMessage] = useState('');
  const [activeclass, setActiveClass] = useState('');
  const [selectedOption, setSelectedOption] = useState('Any source');
  const [selectedLyroUsage, setSelectedLyroUsage] = useState([]);
  const [selectedSortOrder, setSelectedSortOrder] = useState('Newest first');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedSources, setSelectedSources] = useState([]);
  const [isSourceDropdownOpen, setIsSourceDropdownOpen] = useState(false);
  const [isLyroUsageDropdownOpen, setIsLyroUsageDropdownOpen] = useState(false);
  const [searhSourceFilter, setsearhSourceFilter] = useState(true);

  useEffect(() => {
    const userId = localStorage.getItem('userId');

    const fetchData = async () => {
      if (!userId) {
        console.error('User ID not found');
        setError('User ID not found');
        setLoading(false);
        return;
      }

      try {
        const response = await fetch(`${baseURL}/scrap_data/?userId=${userId}`);
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const result = await response.json();
        const dataWithStatus = result.map((item) => ({
          ...item,
          statusLoading: item.status === 'pending',
        }));
        setData(dataWithStatus);
        setFilteredData(result);
      } catch (error) {
        console.error('Error fetching data:', error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const totalUrlScrape = filteredData.length || 0;

  const handleDelete = async (id) => {
    const isConfirmed = window.confirm(
      'Are you sure you want to delete this record permanently?'
    );
    if (isConfirmed) {
      try {
        const response = await fetch(`${baseURL}/scrap_data/deleteurl/${id}`, {
          method: 'DELETE',
        });
        if (response.ok) {
          setData((prevData) => prevData.filter((item) => item._id !== id));
        } else {
          throw new Error(`Failed to delete record with ID ${id}`);
        }
      } catch (error) {
        console.error('Error deleting record:', error);
        setError(error.message);
      }
    }
  };

  const handleDeletePattern = async (id, patternIndex) => {
    const isConfirmed = window.confirm(
      'Are you sure you want to delete this pattern permanently?'
    );
    if (isConfirmed) {
      try {
        const response = await fetch(
          `${baseURL}/scrap_data/deletepatterns/${id}/${patternIndex}`,
          {
            method: 'DELETE',
          }
        );

        if (!response.ok) {
          throw new Error(`Failed to delete pattern at index ${patternIndex}`);
        }

        // Update the state to reflect the deletion
        setData((prevData) =>
          prevData.map((item) => {
            if (item._id === id) {
              // Check if patterns exist and the index is valid
              if (
                Array.isArray(item.patterns) &&
                patternIndex >= 0 &&
                patternIndex < item.patterns.length
              ) {
                const updatedPatterns = [...item.patterns]; // Clone the array
                updatedPatterns.splice(patternIndex, 1); // Remove the pattern
                return { ...item, patterns: updatedPatterns }; // Update the item with the new patterns array
              } else {
                console.warn(
                  `Patterns array or index is invalid for item with ID: ${id}`
                );
                return item; // Return item without changes if patterns are invalid
              }
            }
            return item; // Return other items unchanged
          })
        );
      } catch (error) {
        console.error('Error deleting pattern:', error);
        setError(error.message);
      }
    }
  };

  const handleWebsiteNameClick = async (id) => {
    try {
      localStorage.setItem('questionId', id);

      const response = await fetch(`${baseURL}/scrap_data/websites/${id}`);
      if (!response.ok) {
        throw new Error(`Error fetching data for ID ${id}`);
      }
      const result = await response.json();

      if (result.scrapData && result.scrapData.scrap_data) {
        const dataWithIdAndTimestamp = result.scrapData.scrap_data
          .filter((item) => item !== null)
          .map((item) => ({
            ...item,
            questionid: item.id,
            usedBy: result.scrapData.usedBy,
            timestamp: item.timestamp || result.scrapData.timestamp,
            id: result.scrapData._id,
          }));

        setSelectedWebsiteData(dataWithIdAndTimestamp);
        setFilteredData(dataWithIdAndTimestamp);
        setSelectedWebsite(dataWithIdAndTimestamp);
        console.log('Fetched result:', dataWithIdAndTimestamp);
        setsearhSourceFilter(false);
      } else {
        console.error('Unexpected data structure:', result);
        setSelectedWebsiteData([]); // Reset if structure is unexpected
      }
    } catch (error) {
      console.error('Error fetching website data:', error);
      setError(error.message);
    }
  };

  const handleCloseForm = () => {
    setShowForm(false);
  };

  const handlePatternClick = (tag, pattern, response, id, patternIndex) => {
    if (!tag || !pattern || !response) {
      console.error('Missing required data:', { tag, pattern, response });
      return;
    }

    let responseText = '';

    if (Array.isArray(response)) {
      responseText = response.join('\n');
    } else if (typeof response === 'object' && response.formal) {
      responseText = response.formal.join('\n');
    } else {
      console.error('Unexpected response structure:', response);
      return;
    }

    setFormData({ tag, pattern, response: responseText, id, patternIndex });
    setShowForm(true); // Show the form for editing
  };

  const handleUpdateData = async () => {
    const { tag, pattern, response, id, patternIndex } = formData;

    const responses = {
      formal: response.split('\n').slice(0, 3),
      informal: response.split('\n').slice(3),
    };

    if (!pattern || !responses) {
      console.error('Missing required data for update');
      return;
    }

    try {
      // Send the PUT request to update the pattern
      const updateResponse = await fetch(`${baseURL}/scrap_data/update/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          tag,
          pattern,
          responses,
          patternIndex,
        }),
      });

      if (!updateResponse.ok) {
        setActiveClass('error_active');
        setMessage('Failed to update data. Please try again');
        throw new Error('Failed to update data');
      }

      setActiveClass('success_active');
      setMessage('Data updated successfully');

      const updatedItem = await updateResponse.json();
      console.log(updatedItem);

      const updatedData = selectedWebsiteData.map((item) => {
        if (item.id === updatedItem.id) {
          // Update the pattern at the specific patternIndex
          const updatedPatterns = [...item.patterns];
          updatedPatterns[patternIndex] = updatedItem.pattern;

          // Create the updated item object
          return {
            ...item,
            patterns: updatedPatterns,
          };
        }
        return item;
      });
      setSelectedWebsiteData(updatedData);

      setFilteredData(updatedData);

      // Close the form after updating
      setShowForm(false);

      // Clear success or error message after 3 seconds
      setTimeout(() => {
        setMessage('');
        setActiveClass('');
      }, 3000);
    } catch (error) {
      console.error('Error updating data:', error);
      setError(error.message);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  // Search Query

  const toggleDropdown = () => setIsDropdownOpen(!isDropdownOpen);

  const applyFilters = () => {
    let filtered = selectedWebsiteData || data;
    console.log('selected', filtered);
    if (searchQuery) {
      // Apply search query filter
      filtered = filtered.filter((item) => {
        const query = searchQuery.toLowerCase().trim();
        const websiteName = extractWebsiteName(item.url)
          ? extractWebsiteName(item.url).toLowerCase().trim()
          : '';
        const patternsMatch =
          item.patterns && Array.isArray(item.patterns)
            ? item.patterns.some((pattern) =>
              pattern.toLowerCase().includes(query)
            ) // Check if any pattern matches the search query
            : false;
        return websiteName.includes(query) || patternsMatch;
      });
    }

    if (selectedSources.length > 0) {
      // Apply source filter
      filtered = filtered.filter((item) => {
        return selectedSources.some(
          (source) => source.toLowerCase() === item.source.toLowerCase()
        );
      });
    }

    // Apply Lyro Usage filter
    if (Array.isArray(selectedLyroUsage) && selectedLyroUsage.length > 0) {
      filtered = filtered.filter((item) => {
        // Ensure item.usedBy is a string and is not undefined
        const usedBy = item.usedBy ? item.usedBy.toLowerCase() : '';
        return selectedLyroUsage.some(
          (usedByFilter) => usedByFilter.toLowerCase() === usedBy
        );
      });
    }

    // Apply sorting
    filtered = filtered.sort((a, b) => {
      return selectedSortOrder === 'Newest first'
        ? new Date(b.timestamp) - new Date(a.timestamp)
        : new Date(a.timestamp) - new Date(b.timestamp);
    });

    setFilteredData(filtered);
  };

  useEffect(() => {
    applyFilters();
  }, [
    searchQuery,
    selectedSources,
    selectedLyroUsage,
    selectedSortOrder,
    data,
  ]);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSourceSelect = (source) => {
    setSelectedSources(
      (prevSources) =>
        prevSources.includes(source)
          ? prevSources.filter((s) => s !== source) // Deselect if already selected
          : [...prevSources, source] // Select if not already selected
    );
  };

  const handleLyroUsageSelect = (usedBy) => {
    setSelectedLyroUsage((prevUsages) => {
      if (prevUsages.includes(usedBy)) {
        return prevUsages.filter((s) => s !== usedBy); // Remove if already selected
      } else {
        return [...prevUsages, usedBy]; // Add to selected list
      }
    });
  };

  const handleSortOrderSelect = (order) => {
    setSelectedSortOrder(order);
  };

  const renderSelectedItems = (selectedItems) => {
    if (selectedItems.length === 0) return 'Any Source';
    if (selectedItems.length === 1) return `${selectedItems[0]}`;
    return `${selectedItems.length} sources`;
  };

  const renderLyroUsage = (selectedUsageItems) => {
    if (selectedUsageItems.length === 0) return 'Any Lyro Usage';
    if (selectedUsageItems.length === 1) return `${selectedUsageItems[0]}`;
    return `${selectedUsageItems.length} usedBy`;
  };

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  return (
    <div>
      <div className='hdr_st_so hdr_deta'>
        <div>
          <h2>Data Sources</h2>
          <p>
            Lyro will use the knowledge you add here to answer customer
            questions.
          </p>
        </div>
        <div className='new-btns'>
          <Link href='/play-ground'>
            <button className='add_new_deta flex items-center'>
              <span className='mr-2'>
                <MdVideoLabel />
              </span>
              Test Lyro
            </button>
          </Link>
          <Link href='/configure/general'>
            <button className='add_new_deta flex items-center'>
              <span className='mr-2'>
                <MdVideoLabel />
              </span>
              Activate
            </button>
          </Link>
        </div>
      </div>

      <div className='search_sections'>
        <div className='filter-container'>
          {/* Search Input Field */}
          <div className='right_side_searchfilter'>
            <div className='filter-option search_option'>
              <label htmlFor='inbox-search' className='filter-label'>
                <svg
                  xmlns='http://www.w3.org/2000/svg'
                  width='16'
                  height='16'
                  viewBox='0 0 24 24'
                  fill='subdued'
                  className='search-icon'
                >
                  <path fill='none' d='M0 0h24v24H0z'></path>
                  <path
                    d='M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z'
                    fill='currentColor'
                  ></path>
                </svg>
              </label>
              <input
                type='search'
                id='inbox-search'
                placeholder='Search Questions'
                value={searchQuery}
                onChange={handleSearchChange}
                className='input_field'
              />
            </div>

            {/* Source filter (multi-select) */}
            {searhSourceFilter && (
              <div className='filter-option'>
                <div
                  className='dropdown'
                  onClick={() => setIsSourceDropdownOpen(!isSourceDropdownOpen)}
                >
                  <input
                    type='text'
                    readOnly
                    value={renderSelectedItems(selectedSources)}
                  />
                  <svg
                    xmlns='http://www.w3.org/2000/svg'
                    width='24'
                    height='24'
                    viewBox='0 0 24 24'
                    className='dropdown-arrow'
                  >
                    <path d='M7 10l5 5 5-5z'></path>
                    <path d='M0 0h24v24H0z' fill='none'></path>
                  </svg>
                </div>
                {isSourceDropdownOpen && (
                  <div className='dropdown-list'>
                    <div
                      className='list_item'
                      onClick={() => handleSourceSelect('Website')}
                    >
                      Website
                    </div>
                    <div
                      className='list_item'
                      onClick={() => handleSourceSelect('Manually Added')}
                    >
                      Manually Added
                    </div>
                    <div
                      className='list_item'
                      onClick={() => handleSourceSelect('Inbox')}
                    >
                      Inbox
                    </div>
                    <div
                      className='list_item'
                      onClick={() => handleSourceSelect('CSV File')}
                    >
                      CSV File
                    </div>
                    <div
                      className='list_item'
                      onClick={() => handleSourceSelect('Zendesk')}
                    >
                      Zendesk
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Lyro Usage filter */}
            <div className='filter-option'>
              <div
                className='dropdown'
                onClick={() =>
                  setIsLyroUsageDropdownOpen(!isLyroUsageDropdownOpen)
                }
              >
                <input
                  type='text'
                  readOnly
                  value={renderLyroUsage(selectedLyroUsage)}
                />
                <svg
                  xmlns='http://www.w3.org/2000/svg'
                  width='24'
                  height='24'
                  viewBox='0 0 24 24'
                  className='dropdown-arrow'
                >
                  <path d='M7 10l5 5 5-5z'></path>
                  <path d='M0 0h24v24H0z' fill='none'></path>
                </svg>
              </div>
              {isLyroUsageDropdownOpen && (
                <div className='dropdown-list'>
                  <div
                    className='list_item'
                    onClick={() => handleLyroUsageSelect('Used By Lyro')}
                  >
                    Used By Lyro
                  </div>
                  <div
                    className='list_item'
                    onClick={() => handleLyroUsageSelect('Not Used By Lyro')}
                  >
                    Not Used By Lyro
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Sorting Filter */}
          <div className='left_side_serch_fltr'>
          <div className='filter-option'>
            <div className='dropdown'>
              <input
                id='react-select-4-input'
                className='dropdown-input'
                readOnly
                value={selectedSortOrder}
                onClick={() =>
                  setSelectedSortOrder(
                    selectedSortOrder === 'Newest first'
                      ? 'Oldest First'
                      : 'Newest first'
                  )
                }
              />
              <svg
                xmlns='http://www.w3.org/2000/svg'
                width='24'
                height='24'
                viewBox='0 0 24 24'
                className='dropdown-arrow'
              >
                <path d='M7 10l5 5 5-5z'></path>
                <path d='M0 0h24v24H0z' fill='none'></path>
              </svg>
            </div>
          </div>
          </div>
        </div>
      </div>

      <div className='scrollAreaViewport'>
        {/* Header with Results and Button */}
        <div className='tablehead-button'>
          <h3>Results: {totalUrlScrape}</h3>

          <button className='add_new_deta flex items-center' onClick={openModal}>
            <span className='mr-2'>
              <MdAdd />
            </span>
            Add
          </button>
        </div>
        <PopUp isOpen={isModalOpen} onClose={closeModal} />
        {/* Conditional Rendering for Table */}
        {loading ? (
          <Loader />
        ) : error ? (
          <p className='error-message'>{error}</p>
        ) : selectedWebsiteData ? (
          <table className='data-table'>

            <thead>
              <tr>
                <th>Question</th>
                <th>Used By</th>
                <th>Last updated</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredData
                .filter((item) => item !== null)
                .flatMap((item) => {
                  // Check if patterns array exists and is valid
                  if (!item.patterns || !Array.isArray(item.patterns)) {
                    console.warn(
                      `Patterns array not found for item with ID: ${item.id}`
                    );
                    return []; // Skip this item if no valid patterns found
                  }

                  // Filter the patterns based on the search query
                  const filteredPatterns = item.patterns.filter((pattern) => {
                    const query = searchQuery.toLowerCase().trim();
                    return pattern.toLowerCase().includes(query); // Case-insensitive search
                  });

                  // If no patterns match the search query, skip this item
                  if (filteredPatterns.length === 0) return [];

                  // Render rows for the filtered patterns
                  return filteredPatterns.map((pattern, index) => (
                    <tr
                      key={`${item.questionid}-${index}`}
                      className='table-row'
                    >
                      <td
                        onClick={() =>
                          handlePatternClick(
                            item.tag,
                            pattern,
                            item.responses,
                            item.id,
                            index
                          )
                        }
                      >
                        {pattern}
                      </td>
                      <td>{item.usedBy}</td>
                      <td>
                        {item.timestamp
                          ? new Date(item.timestamp).toLocaleString()
                          : 'No Date Available'}
                      </td>
                      <td>
                        <button
                          onClick={() => handleDeletePattern(item.id, index)}
                        >
                          <BsTrash />
                        </button>
                      </td>
                    </tr>
                  ));
                })}
            </tbody>
          </table>
        ) : (
          <div>
            <table className='data-table'>
              <thead>
                <tr>
                  <th>
                    <input
                      type='radio'
                      className='big-radio'
                      name='action'
                      value='1'
                    />
                  </th>
                  <th>Name</th>
                  <th>Source</th>
                  <th>Used By</th>
                  <th>Last Updated</th>
                </tr>
              </thead>
              <tbody>
                {filteredData.length > 0 ? (
                  filteredData.map((item) => (
                    <tr key={item._id} className='table-row'>
                      <td>
                        <input
                          type='radio'
                          className='big-radio'
                          name='action'
                          value='1'
                        />
                      </td>
                      <td
                        className={item._id}
                        onClick={() => handleWebsiteNameClick(item._id)}
                        style={{ cursor: 'pointer' }}
                      >
                        {extractWebsiteName(item.url)}
                      </td>
                      <td>{item.source}</td>
                      <td>{item.usedBy}</td>
                      <td>{new Date(item.timestamp).toLocaleString()}</td>
                      <td>
                        <button onClick={() => handleDelete(item._id)}>
                          <BsTrash />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan='6'>No data available</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showForm && (
        <div
          className={`form-container ${showForm ? 'slide-in' : 'slide-out'}`}
        >
          <div className='form-header'>
            <h3>Edit Pattern</h3>
            <button onClick={handleCloseForm}>Close</button>
          </div>
          <form>
            <div className='form-group'>
              <label>Tag</label>
              <input
                type='text'
                name='tag'
                value={formData.tag}
                onChange={handleChange}
              />
            </div>
            <div className='form-group'>
              <label>Pattern</label>
              <input
                type='text'
                name='pattern'
                value={formData.pattern}
                onChange={handleChange}
              />
            </div>
            <div className='form-group'>
              <label>Response</label>
              <textarea
                name='response'
                value={formData.response}
                onChange={handleChange}
              ></textarea>
            </div>
            <button type='button' onClick={handleUpdateData}>
              Save and Close
            </button>
          </form>
        </div>
      )}
      <p className={`${activeclass} notify_message`}>{message}</p>
    </div>
  );
}

export default GetDetails;
