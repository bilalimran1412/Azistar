import React, { useState } from 'react';
import { MdClose } from 'react-icons/md';
import Loader from '../Loader/Loader';
import Section from 'views/Lyro/Configure/Items/Section';

function DropDownForm({ closeForm, onSubmit }) {
  const [url, setUrl] = useState(['']);
  const [showLoader, setShowLoader] = useState(false);
  const [activeTab, setActiveTab] = useState("priority");


  const handleSubmit = (e) => {
    e.preventDefault();
    setShowLoader(true);
    setTimeout(() => {
      setShowLoader(false);
      onSubmit(url);
      closeForm();
    }, 3000);

  };

  const handleAddUrl = () => {
    setUrl([...url, '']);
  };

  const handleRemoveUrl = (index) => {
    if (url.length === 1) {
      return;
    }
    setUrl(url.filter((_, i) => i !== index));
  };
  

  const handleChangeUrl = (e, index) => {
    const updatedUrls = [...url];
    updatedUrls[index] = e.target.value;
    setUrl(updatedUrls);
  };

  return (
    <div className="drop_dwn_form upload_url_scrap_data">
      <div className="inr_drop_dn_frm">
        <div className="frm-outer">
          {/* Header */}
          <div className="hdr_form">
            <div className="title_form">
              <h2>
                Provide website URL to import knowledge
              </h2>
              <p>Choose how you want to share knowledge. This will teach Lyro on how to answer questions related to your business.              </p>
              <div className="icon_close" onClick={closeForm}>
                <MdClose />
              </div>
            </div>

          </div>


          {/* Form */}
          <div className="form_show url_sub_form">
            <div>
              <h3>How to import knowledge?</h3>
            </div>

            {/* Tabs */}
            <div className="tabs">
              <button
                className={`tab ${activeTab === "priority" ? "active" : ""}`}
                onClick={() => setActiveTab("priority")}
              >
                <h6>
                  Scan priority pages
                  <i>
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" role="img" fill="default" className="css-1jraybv e11k6mr30" style={{ minWidth: '18px', minHeight: '18px' }}><path fill="none" d="M0-3h24v24H0z"></path><path d="M8.2 12h1.5v1.5H8.2zM9 4.5c-1.6 0-3 1.4-3 3h1.5C7.5 6.7 8.2 6 9 6s1.5.7 1.5 1.5c0 1.5-2.2 1.4-2.2 3.8h1.5c0-1.6 2.2-1.9 2.2-3.8 0-1.6-1.4-3-3-3"></path></svg>
                  </i>
                </h6>
                <p>Lyro will scan priority nested pages using the top-level domain.</p>
              </button>
              <button
                className={`tab ${activeTab === "single" ? "active" : ""}`}
                onClick={() => setActiveTab("single")}
              >
                <h6>
                  Scan single page
                  <i>
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" role="img" fill="default" className="css-1jraybv e11k6mr30" style={{ minWidth: '18px', minHeight: '18px' }}><path fill="none" d="M0-3h24v24H0z"></path><path d="M8.2 12h1.5v1.5H8.2zM9 4.5c-1.6 0-3 1.4-3 3h1.5C7.5 6.7 8.2 6 9 6s1.5.7 1.5 1.5c0 1.5-2.2 1.4-2.2 3.8h1.5c0-1.6 2.2-1.9 2.2-3.8 0-1.6-1.4-3-3-3"></path></svg>
                  </i>
                </h6>
                <p>Lyro will scan only provided pages to import content.</p>
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              {activeTab === "priority" ? (
                <>
                  <h3>Provide URL</h3>
                  <label className="input_lble_url">

                    <input
                      placeholder="Website URL"
                      required
                      type="text"
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                    />
                    <span>e.g. https://example.com</span>
                  </label>
                </>
              ) : (
                <>
                  {url.map((urlValue, index) => (
                    <label key={index} className="input_lble_url">
                      <div className='ir_form_play'>
                        <input
                          placeholder="Website URL"
                          required
                          type="text"
                          value={urlValue}
                          onChange={(e) => handleChangeUrl(e, index)}
                        />
                        {index !== 0 && ( // Don't show remove button for the first URL
                          <MdClose className="close-btn" onClick={() => handleRemoveUrl(index)} />
                        )}
                      </div>

                      <span>e.g. https://example.com/about</span>

                    </label>
                  ))}
                  <div className="addnew_url">
                    <button
                      type="button"
                      className="btn btn-new btn-size-m btn-link css-1hcx8jb e496m1i4"
                      onClick={handleAddUrl}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" className="css-0 e11k6mr30">
                        <path fill="none" d="M0 0h24v24H0z"></path>
                        <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"></path>
                      </svg>
                      <span>Add next URL</span>
                    </button>
                  </div>
                </>
              )}
              <p className='flex bottom_pop_ftr'>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" className="css-0 e11k6mr30" style={{ minWidth: '24px', minHeight: '24px' }}><path fill="none" d="M0 0h24v24H0z"></path><path d="M11 7h2v2h-2zm0 4h2v6h-2zm1-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8"></path></svg>
                This process may take a few minutes and will continue in the background.
              </p>
              <div className="submit_btn">
                <button className="btn" type="submit" disabled={showLoader}>
                  {showLoader ? "Uploading..." : "Import Knowledge"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DropDownForm;