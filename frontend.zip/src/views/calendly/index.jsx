import CalendlyEmbed from "./CalendlyEmbed";

export default function Home() {
  return (
    <div className="container">
      <h1>Schedule an Appointment</h1>
      <CalendlyEmbed url="https://calendly.com/codewithpassion3/30min" />

        
    </div>
  );
}