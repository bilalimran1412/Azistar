import React from 'react';
import ChatwootWidget from '../../ui-component/chatwoot/chatwoot';

function Chats() {
  return (
    <ChatwootWidget/>
  )
}

export default Chats;
