import React from 'react'
import Assigned from './Assigned'

function index() {
  return (
    <Assigned/>
  )
}

export default index