import React from 'react'
import Chatbot from '../LiveChat/ChatBot'

function ChatbotUser() {
  return (
    <div className='chatbotContainer'>
            <Chatbot />
    </div>
  )
}

export default ChatbotUser