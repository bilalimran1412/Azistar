import React from 'react'
import Solved from './solved'

function index() {
  return (
    <Solved/>
  )
}

export default index