import React from 'react'
import Suggestions from './suggestions'

function index() {
  return (
    <Suggestions/>
  )
}

export default index