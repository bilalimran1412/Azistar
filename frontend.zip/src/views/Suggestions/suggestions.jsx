import React, { useEffect, useState } from 'react';
import Lyroheader from '../../components/LyroAi/Lyroheader';
import { MdAdd } from 'react-icons/md';
import Table from './table';
import axios from 'axios';
import TabComponent from 'components/TabComponent/Tab';

function Suggestions() {
    const [unanswered, setUnanswered] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const baseURL = process.env.REACT_APP_API_BASE_URL;

    useEffect(() => {
        const userId = localStorage.getItem('userId');

        if (!userId) return;

        const fetchUnansweredQuestionsByUser = async () => {
            try {
                const response = await axios.get(`${baseURL}/chat/unanswered-questions/${userId}`);
                console.table(response.data);
                setUnanswered(response.data);
                console.log('Unanswered questions for user:', response.data);
            } catch (err) {
                setError('Failed to fetch unanswered questions.');
            } finally {
                setLoading(false);
            }
        };

        fetchUnansweredQuestionsByUser();
    }, [baseURL]);

    if (loading) return <p>Loading...</p>;
    if (error) return <p>{error}</p>;

    const unansweredCount = unanswered?.length || 0;

    const tabs = [
        {
            label: `Unanswered Questions (${unansweredCount})`,
            content: (
                <>
                    {loading && <p>Loading...</p>}
                    {error && <p>{error}</p>}
                    {!loading && unanswered.length > 0 ? (
                        <div className="scrollAreaViewport">
                            <Table data={unanswered} />
                        </div>
                    ) : (
                        !loading && (
                            <div className="mn-box-select">
                                <div className="inr_dat_box">
                                    <svg
                                        width="52"
                                        height="52"
                                        viewBox="0 0 52 52"
                                        fill="none"
                                        xmlns="http://www.w3.org/2000/svg"
                                    >
                                        <rect width="52" height="52" rx="26" fill="#DCE9FF"></rect>
                                        <path
                                            d="M18 16H34C34.5304 16 35.0391 16.2107 35.4142 16.5858C35.7893 16.9609 36 17.4696 36 18V30C36 30.5304 35.7893 31.0391 35.4142 31.4142C35.0391 31.7893 34.5304 32 34 32H27.9L24.2 35.71C24 35.9 23.75 36 23.5 36H23C22.7348 36 22.4804 35.8946 22.2929 35.7071C22.1054 35.5196 22 35.2652 22 35V32H18C17.4696 32 16.9609 31.7893 16.5858 31.4142C16.2107 31.0391 16 30.5304 16 30V18C16 16.89 16.9 16 18 16ZM26.19 19.5C25.3 19.5 24.59 19.68 24.05 20.04C23.5 20.4 23.22 21 23.27 21.69H25.24C25.24 21.41 25.34 21.2 25.5 21.06C25.7 20.92 25.92 20.85 26.19 20.85C26.5 20.85 26.77 20.93 26.95 21.11C27.13 21.28 27.22 21.5 27.22 21.8C27.22 22.08 27.14 22.33 27 22.54C26.83 22.76 26.62 22.94 26.36 23.08C25.84 23.4 25.5 23.68 25.29 23.92C25.1 24.16 25 24.5 25 25H27C27 24.72 27.05 24.5 27.14 24.32C27.23 24.15 27.4 24 27.66 23.85C28.12 23.64 28.5 23.36 28.79 23C29.08 22.63 29.23 22.24 29.23 21.8C29.23 21.1 28.96 20.54 28.42 20.12C27.88 19.71 27.13 19.5 26.19 19.5ZM25 26V28H27V26H25Z"
                                            fill="#0566FF"
                                        ></path>
                                    </svg>

                                    <h2>No unanswered questions</h2>
                                    <p>
                                        Here you'll find questions from the last 30 days that Lyro doesn't know the
                                        answer to. You will be able to add responses. Remember to check back later for
                                        new updates.
                                    </p>
                                </div>
                            </div>
                        )
                    )}
                </>
            ),
        },
        // Add other tabs here if needed
    ];

    return (
        <div>
            <div className="main-data-sources">
                <Lyroheader
                    title="Suggestions"
                    text="Complete suggested questions to help Lyro deal with similar questions in the future. Suggestions are based on questions your customers are likely to ask and ones that Lyro could not answer because of lack of knowledge."
                    Fhref="/data-sources/added"
                    FIcon={<MdAdd />}
                    buttonText="Test Lyro"
                    Shref="/configure/general"
                    Sclass="add_new_deta"
                    SIcon={<MdAdd />}
                    buttonSText="Activate"
                />
            </div>
            <div className="configure_info container mx-auto mt-8">
                <TabComponent tabs={tabs} />
            </div>
        </div>
    );
}

export default Suggestions;
