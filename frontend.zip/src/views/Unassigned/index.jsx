import UnassignChat from './UnassignChat';
const Index = () => {
  return (
    <>
    <UnassignChat />
    </>
);
};

export default Index;
